This Java tools version was built from the bazel repository at commit hash 50c876e337a6e40ade7069d46649ae71296cfc14
using bazel version 0.26.0.
To build from source the same zip run the commands:

$ git clone https://github.com/bazelbuild/bazel.git
$ git checkout 50c876e337a6e40ade7069d46649ae71296cfc14
$ bazel build //src:java_tools_java11.zip
