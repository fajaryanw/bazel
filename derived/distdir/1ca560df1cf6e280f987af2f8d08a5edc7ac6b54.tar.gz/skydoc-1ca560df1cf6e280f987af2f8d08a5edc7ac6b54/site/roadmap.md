---
layout: default
title: Roadmap
stylesheet: docs
---

* Document default values for rule and macro attributes.
* Enable greater customization of generated documentation, such as adding custom
  HTML and CSS to the documentation pages.
* Improve documentation for Skylark
  [Aspects](https://www.bazel.build/docs/skylark/aspects.html) and
  [Repository Rules](https://www.bazel.build/docs/skylark/repository_rules.html).
